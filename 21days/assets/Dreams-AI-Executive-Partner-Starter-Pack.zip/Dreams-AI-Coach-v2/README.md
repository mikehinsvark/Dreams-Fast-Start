# Dreams Coach — Beginner-to-Productive Rep Starter Pack

Version: 2.0  
Updated: September 23, 2026

Start with one useful conversation and one next action. This revision helps a new Dreams representative practice, make appropriate specialist introductions, and follow through. Skills and real results guide progress; dates and suggested activity counts are planning aids.

## New to AI? Start here

For the easiest reading experience, open [START-HERE.html](START-HERE.html) in your browser. It contains the same starter message and a short visual setup guide.

1. Open [Start Here](AGENT-READY/00-START-HERE.md).
2. Copy the **Begin now in one chat** message into a ChatGPT conversation you can access.
3. Answer one question at a time, practice a short conversation, and choose one Next Meaningful Action.
4. Return with what you did, what happened, and what comes next. Save the short progress note so you can paste it into your next conversation.

You do not need to read the whole pack, finish the profile, upload files, buy another app, or arrange several AI tools before the first practice. Typing is enough; Voice is optional where available. If setup is confusing, ask your sponsor for help and continue practicing.

## Ready for a continuing coach?

Follow the optional setup in [Start Here](AGENT-READY/00-START-HERE.md). Where your account supports a project, add these **four reference files** from `AGENT-READY`:

| Upload file | What it provides |
|---|---|
| [01-DREAMS-EXECUTIVE-PARTNER-CORE-MEMORY.md](AGENT-READY/01-DREAMS-EXECUTIVE-PARTNER-CORE-MEMORY.md) | Coaching approach, referral boundaries, flexible 21-day plan, and readiness checks |
| [02-MY-DREAMS-OPERATING-PROFILE.md](AGENT-READY/02-MY-DREAMS-OPERATING-PROFILE.md) | A few useful facts about you, completed gradually |
| [03-DREAMS-MEMORY-JOURNAL.md](AGENT-READY/03-DREAMS-MEMORY-JOURNAL.md) | Brief notes about actual actions, results, and next steps |
| [04-AI-HANDOFF-PLAYBOOK.md](AGENT-READY/04-AI-HANDOFF-PLAYBOOK.md) | Human specialist introductions and optional AI preparation handoffs |

Copy [PROJECT-INSTRUCTIONS.txt](PROJECT-INSTRUCTIONS.txt) into the project's instructions area where shown. Ask the coach to confirm which files it can actually read. If these features are unavailable, continue with the starter message and saved progress note; missing setup should not block practice. See the [official Projects guide](https://learn.chatgpt.com/docs/projects) for current setup help.

The five Genie roles—Coach, Onboarding, Sales, Intelligence, and Partnership—support one coaching relationship. “Executive Partner” describes greater coaching depth, not another independent agent. Extra applications are optional.

## Keep progress you can trust

An AI-generated note is a draft. Chat history, downloaded files, project uploads, and other tools are separate; this pack does not guarantee automatic memory, file updates, synchronization, monitoring, or background work.

Review a proposed update, save it, replace the older upload when appropriate, and ask the coach to read back the changed date and content. If that cannot be verified, keep a short resume note and paste it into the next conversation. Use aliases or categories and leave private client records out of coaching files.

The representative opens conversations and supports the relationship. The appropriate specialist determines fit, explains current terms, and handles technical work. **Confirm the approved specialist referral and booking route with your sponsor before referring.** These documents do not supply a verified booking link or promise results.

## Sources and provenance

This is a September 23, 2026 revision of the [public Dreams AI Executive Partner Starter Pack](https://dreamsfaststart.com/21days/assets/Dreams-AI-Executive-Partner-Starter-Pack.zip), whose reviewed source documents were version 1.0 dated September 14, 2026. The original downloaded pack is preserved separately.

Public starting points checked for this revision:

- [21-Day Fast Start](https://dreamsfaststart.com/21days/), including its Week 1–3 sections.
- [Dreams training hub](https://dreamsfaststart.com/) for orientation; obtain the exact current approved lesson from your sponsor.
- [Dreams Back Office](https://dreams.poweredagency.com/) through your own access.

These links identify starting locations, not proof of current program terms, eligibility, compensation, specialist availability, or authorization. Current official Dreams and provider material controls. Do not infer a contact, lesson, or booking destination that has not been confirmed.

For team rollout, [PILOT-CHECKLIST.md](PILOT-CHECKLIST.md) provides a three-rep usability test plan. The checklist itself is not evidence that user testing has been completed.
