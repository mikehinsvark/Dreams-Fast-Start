# Dreams AI Coach: three-rep pilot

**Status: test plan only. No user tests or website checks are recorded as completed.**

Use three reps, one per scenario, for 10 minutes each. Use fictional names; no real outreach. Give them the starter page without explaining AI, files, Projects, or Genies. Observe quietly and record obstacles before helping.

Record device, times to first reply and next action, help requests, confusing words, and pass/fail. Ask: “What will you do next, and where is it saved?” Targets: first reply within 3 minutes; usable action within 10 minutes without rescue. Record login delays separately.

## Three short sessions

| Rep | Starting situation and task | What must happen |
| --- | --- | --- |
| 1: phone beginner | “I have never used AI. Help me start a conversation with a business owner.” Begin on a phone. | Starts in one chat without required Project setup or uploads. Coach asks one question, waits, provides a sample opener, then offers supported practice. Rep understands the opener. |
| 2: limited time, no contacts | “I have 10 minutes, no prospect list, and don't know which specialist to use.” | Chooses one realistic next step, using the sponsor for an introduction or specialist route when needed. No invented specialist, service promise, large contact list, or multiple priorities. |
| 3: returning after a week | Reopen the chat or use saved resume notes. Say: “It's been a week. Help me pick up where I left off.” | Confirms the prior action, asks what happened, records **Done**, **Tried**, or **Not started**, then agrees one updated action. No assumed completion. |

After rep 3's run, use “invitation sent” as the agreed done criterion: **Done:** “I sent it; no reply.” **Tried:** “I tried, but the app failed and it wasn't sent.” **Not started:** “I didn't try.” Also confirm an unanswered call attempt is **Done** when the agreed criterion was “call attempted.” Evaluate action status against its agreed done criterion; record the recipient's response separately.

## Coaching acceptance criteria

- [ ] One coach, one chat; optional setup never blocks starting.
- [ ] One question per turn, followed by a pause; no stacked intake or unexplained AI terms.
- [ ] Sample opener precedes optional supported practice and brief feedback.
- [ ] One **next meaningful action** includes **person, action, owner, due date/time, and definition of done**. “Follow up soon” fails. Asking the sponsor for one introduction is valid.
- [ ] Agent identifies needs, obtains permission, arranges specialist conversations, and follows through. Unknown specialist routes go through the sponsor.
- [ ] Status matches reported events and the agreed done criterion. Record responses separately: a completed call attempt can be Done without an answer; a sent invitation is not a booked appointment.
- [ ] Rep distinguishes **generated notes**, **downloaded file**, and **verified saved profile/journal update**. Coach never claims a source file changed without evidence.

## Website and download checks

Before the pilot, record device/browser, result, and evidence for each check.

- [ ] Copy button pastes the complete prompt correctly. Success message appears only after successful copying.
- [ ] With clipboard unavailable, visible prompt supports manual selection/copy with plain instructions.
- [ ] Four individual downloads open, have clear filenames, and match their ZIP copies exactly. ZIP opens with advertised contents; no stale versions or broken links.
- [ ] Phone labels explain actions; controls are discoverable and tappable; text is readable without overlap or horizontal scrolling.
- [ ] **If local save exists:** enter fictional data, save, reload, and verify accuracy. Labels explain browser/device storage without implying AI memory or cloud sync.
- [ ] **If resume download exists:** downloaded notes contain the latest action/status, date, and resume instructions. A fresh chat can use them without hidden prior context.

**Release decision:** all three reps complete the core path and applicable checks pass. False saves, invented services/specialists, incorrect status, broken downloads, or inaccessible mobile controls block release. Mark absent optional features “not implemented.” Revise failures and retest with a fresh beginner.
