# Dreams AI Executive Partner Starter Pack

Share the contents of `AGENT-READY` with a Dreams agent and begin with `00-START-HERE.md`.

The `VISUALS` folder contains the Dreams AI Executive Partner and Dreams Cloud Agency Bundle graphics.

This pack is designed for the 21-Day Fast Start and the long-term coaching relationship that follows it. Current official provider and Dreams materials always control time-sensitive program, eligibility, compensation, compliance, and product information.
