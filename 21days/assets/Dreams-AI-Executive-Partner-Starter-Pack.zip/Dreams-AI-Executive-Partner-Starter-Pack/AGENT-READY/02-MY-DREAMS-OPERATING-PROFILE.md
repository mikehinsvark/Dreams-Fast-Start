# My Dreams Operating Profile

Owner: [Your name]  
Dreams agent ID: [AA####]  
Sponsor or field leader: [Name]  
Preferred AI partner name: [Example: Jarvis]  
Last updated: [YYYY-MM-DD]

Only record information you are comfortable using as AI context. Do not include passwords, bank details, Social Security numbers, health information, tax records, identity documents, confidential client files, or private information about another person.

## 1. Why I am building Dreams

My primary reason:

[Write 2–5 sentences]

What success would make possible for me or my family:

[Write 2–5 sentences]

## 2. My current phase

- Current phase: [Days 1–21 / Days 22–90 / Day 91+]
- Current Fast Start day or week, if applicable:
- Current weekly product focus:
- Date I enrolled:
- Date I started active production:

## 3. My outcomes

### Next 21 days

- Production outcome:
- Skill outcome:
- System outcome:

### Next 90 days

- Production outcome:
- Income goal, if useful:
- Recurring-income goal, if useful:
- Partnership goal:
- Leadership or recruiting goal:

### Next 12 months

- Business outcome:
- Lifestyle outcome:
- Leadership outcome:

## 4. My Freedom Metric

- Monthly recurring income: $[amount]
- Monthly living expenses: $[amount]
- Freedom Metric: `[monthly recurring income] ÷ [monthly living expenses] = [result]`
- Next milestone:

This is a personal planning metric, not a guarantee or forecast.

## 5. My available time

- Dreams hours per week:
- Best prospecting days and times:
- Best training days and times:
- Preferred Daily Huddle time:
- Preferred End-of-Day Debrief time:
- Weekly Business Review time:
- Real constraints the coach should respect:

## 6. My background and assets

- Current or prior occupation:
- Relevant industries:
- Existing business-owner relationships:
- Existing professional relationships, such as CPAs, payroll firms, brokers, lenders, consultants, Chambers, or associations:
- Communities or geographic markets I understand:
- Languages:
- Technology and AI comfort level:

## 7. My strengths and growth edges

My strongest skills:

- 
- 
- 

Skills I am building:

- 
- 
- 

What I tend to avoid or overthink:

- 

How I want my coach to challenge me:

- [Gentle / direct / very direct]
- [Questions first / recommendation first]
- [Short answers / detailed explanations]

## 8. My target markets

### Primary market for the next 30 days

- Market:
- Why it fits me:
- Typical contact:
- Likely conversation opener:
- Current approved source or training:

### Secondary market

- Market:
- Why it fits me:

## 9. My current pipeline snapshot

Do not include sensitive client information. Initials or company categories are enough.

| Prospect or category | Product conversation | Stage | Next action | Due date |
|---|---|---|---|---|
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |

## 10. My current scorecard

Current week: [YYYY-MM-DD to YYYY-MM-DD]

| Activity | Weekly target | Completed |
|---|---:|---:|
| New contact attempts |  |  |
| Live conversations |  |  |
| Follow-ups |  |  |
| Appointment asks |  |  |
| Specialist appointments scheduled |  |  |
| Appointments held |  |  |
| Referrals submitted |  |  |
| Role-play or training minutes |  |  |

## 11. Language that sounds like me

Words or phrases I naturally use:

- 

Words, styles, or clichés I do not want:

- 

My preferred one-sentence description of what I do:

> [Write it here]

## 12. My AI operating system

Mark what is available to me:

- [ ] ChatGPT / Voice — thinking, coaching, role-play, decisions
- [ ] Claude / Cowork — documents, builds, deep work
- [ ] Grokbot — persistent agent operations and automation
- [ ] NotebookLM — source-grounded study and synthesis
- [ ] Other:

My standard handoff process:

[Example: My Executive Partner drafts a handoff prompt; I run it in the named tool; I bring the result back for review.]

## 13. Current commitments

My single highest-priority business outcome:

[Write it here]

This week's non-negotiable actions:

1. 
2. 
3. 

The number I will report at my next Daily Huddle:

[Write it here]

