# Dreams AI Handoff Playbook

Version: 1.0  
Updated: September 14, 2026

## One brain, four AI bodies

The agent remains the CEO. The Dreams Executive Partner keeps the strategy and context coherent, then routes work to the best available tool.

| AI role | Best used for | Do not assume |
|---|---|---|
| ChatGPT / Voice — **Think** | Coaching, role-play, decisions, prioritization, conversation practice | It can silently edit your source files or operate every external tool |
| Claude / Cowork — **Do** | Building documents, analyzing larger workspaces, drafting assets, completing focused projects | It automatically knows the current state of ChatGPT or Grokbot |
| Grokbot — **Operate** | Persistent agents, monitored workflows, recurring operations, delegated task execution | An action succeeded without a returned result or verification |
| NotebookLM — **Learn** | Source-grounded study, comparison, synthesis, and answers from an approved source set | Its source set is current unless you maintain it |

If a platform changes, keep the roles rather than forcing the old tool name.

## Routing rules

Use ChatGPT / Voice when the agent needs to think, decide, practice, or be coached.

Use Claude / Cowork when the desired output is a substantial file, analysis, workflow, or build.

Use Grokbot when the work must persist, repeat, monitor, or operate beyond one conversation.

Use NotebookLM when accuracy depends on a specific collection of approved documents.

No AI may claim another AI performed work unless a connection exists and the returned result verifies completion.

## Universal handoff packet

Every handoff should contain:

```text
HANDOFF: [ChatGPT / Claude / Grokbot / NotebookLM]

OBJECTIVE
[The one outcome required]

BUSINESS CONTEXT
[Only the Dreams and agent context needed]

INPUTS
[Files, links, source text, or prior decisions]

DELIVERABLE
[Exact format and completion criteria]

GUARDRAILS
- Do not invent facts, claims, results, eligibility, savings, approval, or compensation.
- Flag time-sensitive claims for current official verification.
- Preserve confidential information and use the minimum necessary data.
- Follow the Dreams referral model and route technical determinations to specialists.

RETURN FORMAT
1. Completed result
2. Assumptions
3. Items requiring verification
4. Recommended next action
```

## Genie routing

The Dreams Executive Partner may invoke these specialist roles directly or prepare a handoff for an existing Genie.

| Need | Genie or hat | Expected output |
|---|---|---|
| New-agent next step | Onboarding Genie | One lesson, one action, one check for understanding |
| Opening, objection, or appointment practice | Sales Genie | Role-play, score, one improvement, retry |
| Consistency or avoidance | Coach Genie | Evidence-based accountability and a timed commitment |
| Prospect or market research | Intelligence Genie | Facts, assumptions, source dates, useful questions |
| CPA, payroll, Chamber, or alliance | Partnership Genie | Mutual-value strategy and a concrete next step |
| Strategy, systems, or leadership | Executive Partner | Decision, rationale, operating plan, metric |

## Return-to-partner protocol

After using another AI, return the result to the Executive Partner with:

> Review this handoff result against my Dreams Core Memory, current goal, and guardrails. Tell me what to accept, revise, verify, or reject. Then give me one next action and any journal or profile update.

The Executive Partner should not merely admire the output. It should integrate it into the agent's plan and memory.

## Source-grounding protocol

For program details, compliance, provider criteria, scripts containing specific numbers, or other time-sensitive claims:

1. Identify the current official source.
2. Record its title, owner, and date.
3. Separate direct source facts from inference.
4. Ask the appropriate provider or Dreams leader to resolve conflicts.
5. Update the Core Memory only after approval.

Older notes remain useful for ideas, but they do not outrank current official material.

