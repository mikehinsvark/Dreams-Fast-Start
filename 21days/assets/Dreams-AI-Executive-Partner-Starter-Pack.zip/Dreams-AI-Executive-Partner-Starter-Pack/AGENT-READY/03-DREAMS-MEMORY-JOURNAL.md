# Dreams Memory Journal

Owner: [Your name]  
Started: [YYYY-MM-DD]

This is a curated memory file, not a transcript dump. Save only information that will improve future coaching. Use initials or business categories instead of sensitive prospect or client details.

## What belongs here

- Measurable wins and activity patterns
- Scripts or questions tested in real conversations
- Objections heard repeatedly
- Lessons from appointments and follow-up
- Commitments and whether they were completed
- Decisions, market focus, and reasons
- Durable coaching preferences
- Profile changes that should be carried forward

## What does not belong here

- Passwords or credentials
- Social Security numbers or identity documents
- Bank, credit-card, tax, payroll, or health records
- Confidential client files
- Unsupported claims or AI guesses presented as facts
- Long raw transcripts

---

## Journal entry template

### YYYY-MM-DD — [Short title]

**Phase and focus:**  
[Example: Fast Start, Week 1 R&D]

**Activity completed:**

- New contacts:
- Live conversations:
- Follow-ups:
- Appointment asks:
- Appointments scheduled:
- Other:

**What happened:**  
[2–5 sentences]

**Language or approach tested:**

> [Short script, question, or positioning statement]

**Response or objection:**  
[What the prospect actually said, with private details removed]

**Lesson:**  
[What should change or continue]

**Next commitment:**  
[One measurable action, number, and time]

**Profile update needed:**  
[None, or describe the durable change]

**Source check needed:**  
[None, or the claim/question that needs current official verification]

---

## Weekly consolidation template

### Week ending YYYY-MM-DD

**Scorecard:**

| Activity | Target | Completed | Note |
|---|---:|---:|---|
| New contact attempts |  |  |  |
| Live conversations |  |  |  |
| Follow-ups |  |  |  |
| Appointment asks |  |  |  |
| Specialist appointments scheduled |  |  |  |
| Appointments held |  |  |  |
| Referrals submitted |  |  |  |

**Three wins:**

1. 
2. 
3. 

**Biggest bottleneck:**  
[List / outreach / response / discovery / appointment ask / show rate / follow-up / other]

**Most useful lesson:**  
[Write it here]

**One skill to drill next week:**  
[Write it here]

**One production priority next week:**  
[Write it here]

**Profile updates to make:**

- 

**Claims or training to verify:**

- 

---

## Entries

Add the newest entry immediately below this line.

